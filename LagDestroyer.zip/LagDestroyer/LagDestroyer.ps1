# Lag Destroyer - Windows Services Tuner
# Stylová verze s ASCII menu, volbou Disable Telemetry a logováním

# Kontrola spuštění jako správce
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltinRole] "Administrator")) {
    Write-Warning "Please run this script as Administrator!"
    Write-Host "Press any key to exit..."
    [void][System.Console]::ReadKey($true)
    exit
}

$logPath = "$PSScriptRoot\LagDestroyer_log.txt"

function Log-Action {
    param([string]$message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$timestamp - $message" | Out-File -FilePath $logPath -Append -Encoding utf8
}

function Pause {
    Write-Host "Press any key to continue..."
    [void][System.Console]::ReadKey($true)
}

function Show-Menu {
    Clear-Host
    Write-Host ""
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host "         Lag Destroyer - Service Optimizer"
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "   [1] Disable background services" -ForegroundColor White
    Write-Host "       Disables telemetry, Xbox, search and other services. Safe." -ForegroundColor Gray
    Write-Host "   [2] Activate Performance Mode" -ForegroundColor White
    Write-Host "       Enables ultimate power plan and disables visual effects. Safe." -ForegroundColor Gray
    Write-Host "   [3] Disable Telemetry" -ForegroundColor White
    Write-Host "       Stops Windows telemetry and related scheduled tasks. Safe." -ForegroundColor Gray
    Write-Host "   [4] Show Log" -ForegroundColor White
    Write-Host "       View actions log file." -ForegroundColor Gray
    Write-Host "   [5] Exit" -ForegroundColor White
    Write-Host ""
}

function Disable-Services {
    Write-Host "`n>>> Disabling unnecessary services..." -ForegroundColor Yellow
    $services = @(
        "DiagTrack", "SysMain", "WSearch", "XblGameSave",
        "XboxNetApiSvc", "XboxGipSvc", "RetailDemo", "MapsBroker",
        "Fax", "RemoteRegistry", "dmwappushsvc", "WMPNetworkSvc",
        "MessagingService", "SharedAccess"
    )
    foreach ($svc in $services) {
        Get-Service -Name $svc -ErrorAction SilentlyContinue | ForEach-Object {
            if ($_.Status -ne "Stopped") {
                Stop-Service -Name $_.Name -Force
            }
            Set-Service -Name $_.Name -StartupType Disabled
            Write-Host "   > Disabled: $($_.DisplayName)" -ForegroundColor DarkGray
            Log-Action "Disabled service: $($_.Name)"
        }
    }
    Write-Host "`n✅ Background services disabled." -ForegroundColor Green
    Log-Action "Background services disabled."
    Add-Content -Path $logPath -Value "`nTo re-enable these services, run the script again and set startup type to 'Automatic' and start the services manually."
    Pause
}

function Activate-Performance {
    Write-Host "`n>>> Activating performance settings..." -ForegroundColor Yellow
    powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 | Out-Null
    powercfg -setactive e9a42b02-d5df-448d-aa00-03f14749eb61
    $regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"
    Set-ItemProperty -Path $regPath -Name VisualFXSetting -Value 2 -Force
    Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name "UserPreferencesMask" -Value ([byte[]](0x90,0x12,0x03,0x80,0x10,0x00,0x00,0x00)) -Force
    Write-Host "   > Ultimate Power Plan set"
    Write-Host "   > Visual Effects optimized"
    Write-Host "`n✅ Performance mode activated." -ForegroundColor Green
    Log-Action "Performance mode activated."
    Add-Content -Path $logPath -Value "`nTo revert visual effects, set VisualFXSetting to 1 or adjust in system settings."
    Pause
}

function Disable-Telemetry {
    Write-Host "`n>>> Disabling telemetry..." -ForegroundColor Yellow
    Stop-Service -Name "DiagTrack" -Force -ErrorAction SilentlyContinue
    Set-Service -Name "DiagTrack" -StartupType Disabled
    New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Force | Out-Null
    Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "AllowTelemetry" -Value 0 -Type DWord
    Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\SQMClient\Windows" -Name "CEIPEnable" -Value 0 -Force
    New-Item -Path "HKCU:\Software\Microsoft\Siuf\Rules" -Force | Out-Null
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Siuf\Rules" -Name "NumberOfSIUFInPeriod" -Value 0 -Force
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Siuf\Rules" -Name "PeriodInNanoSeconds" -Value 0 -Force
    $tasks = @(
        "\Microsoft\Windows\Application Experience\ProgramDataUpdater",
        "\Microsoft\Windows\Autochk\Proxy",
        "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator",
        "\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask",
        "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip",
        "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector"
    )
    foreach ($task in $tasks) {
        schtasks /Change /TN $task /Disable | Out-Null
    }
    Write-Host "`n✅ Telemetry disabled." -ForegroundColor Green
    Log-Action "Telemetry disabled."
    Add-Content -Path $logPath -Value "`nTo re-enable telemetry, change AllowTelemetry value to 1 and enable scheduled tasks."
    Pause
}

function Show-Log {
    if (Test-Path $logPath) {
        Write-Host "`n=== Log file contents ===`n" -ForegroundColor Cyan
        Get-Content $logPath | ForEach-Object { Write-Host $_ }
    }
    else {
        Write-Host "No log file found." -ForegroundColor Yellow
    }
    Pause
}

do {
    Show-Menu
    $choice = Read-Host "   Choose"

    switch ($choice) {
        "1" { Disable-Services }
        "2" { Activate-Performance }
        "3" { Disable-Telemetry }
        "4" { Show-Log }
        "5" { Write-Host "`nExiting..." -ForegroundColor Cyan }
        default {
            Write-Host "`n[!] Invalid input, please choose 1 - 5." -ForegroundColor Red
            Pause
        }
    }
} until ($choice -eq "5")
