Lag Destroyer - Windows Services Tuner
What is this?
A PowerShell script to improve Windows 10/11 performance by disabling unnecessary services (telemetry, Xbox, search), enabling high performance mode, and turning off visual effects.

How to use
Download the whole folder.

Make sure LagDestroyer.ps1 and LagDestroyer_RunAsAdmin.bat are in the same folder.

Run LagDestroyer_RunAsAdmin.bat as admin.

Pick an option in the menu to disable services, enable performance mode, disable telemetry, view log, or exit.

Important
Run as Administrator! The script needs admin rights to change system settings.

Log
The script creates a log file with details of what actions were done.

Undo changes
Check the log for tips on how to revert changes if needed.

License
MIT License — free to use and modify.

More info & download
https://github.com/d0mess666/Lag-Destroyer?tab=readme-ov-file