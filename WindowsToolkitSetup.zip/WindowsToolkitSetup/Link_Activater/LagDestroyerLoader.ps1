Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = "Windows Toolkit Setup"
$form.BackColor = "Black"
$form.ForeColor = "LightBlue"
$form.Size = New-Object System.Drawing.Size(800, 500)
$form.StartPosition = "CenterScreen"

$title = New-Object System.Windows.Forms.Label
$title.Text = "Windows Toolkit Setup"
$title.Font = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = "LightBlue"
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(20, 10)
$form.Controls.Add($title)

$clock = New-Object System.Windows.Forms.Label
$clock.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$clock.ForeColor = "LightGreen"
$clock.AutoSize = $true
$clock.Location = New-Object System.Drawing.Point(700, 15)
$form.Controls.Add($clock)

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 1000
$timer.Add_Tick({
    $clock.Text = (Get-Date).ToString("HH:mm:ss")
})
$timer.Start()

$description = New-Object System.Windows.Forms.Label
$description.Text = "This toolkit helps improve performance, remove bloat and optimize Windows 11 safely."
$description.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$description.AutoSize = $true
$description.Location = New-Object System.Drawing.Point(20, 50)
$form.Controls.Add($description)

$link = New-Object System.Windows.Forms.LinkLabel
$link.Text = "GitHub Repository"
$link.LinkColor = "SkyBlue"
$link.Location = New-Object System.Drawing.Point(20, 80)
$link.AutoSize = $true
$link.Add_Click({ Start-Process "https://github.com/d0mess666/windows-toolkit" })
$form.Controls.Add($link)

$logBox = New-Object System.Windows.Forms.TextBox
$logBox.Multiline = $true
$logBox.ScrollBars = "Vertical"
$logBox.BackColor = "Black"
$logBox.ForeColor = "White"
$logBox.ReadOnly = $true
$logBox.Location = New-Object System.Drawing.Point(20, 300)
$logBox.Size = New-Object System.Drawing.Size(740, 130)
$form.Controls.Add($logBox)

$progressBar = New-Object System.Windows.Forms.ProgressBar
$progressBar.Location = New-Object System.Drawing.Point(20, 440)
$progressBar.Size = New-Object System.Drawing.Size(740, 20)
$form.Controls.Add($progressBar)

$scriptsPath = Join-Path $PSScriptRoot "..\scripts\powershell_scripts"

function Run-Script {
    param([string]$scriptName)

    $fullPath = Join-Path $scriptsPath $scriptName
    if (-Not (Test-Path $fullPath)) {
        [System.Windows.Forms.MessageBox]::Show("Script not found:`n$fullPath", "Error", "OK", "Error")
        return
    }

    $progressBar.Value = 0
    $logBox.AppendText("Running $scriptName...`r`n")

    $job = Start-Job -ScriptBlock {
        param($path)
        powershell.exe -NoProfile -ExecutionPolicy Bypass -File $path
    } -ArgumentList $fullPath

    while ($job.State -eq "Running") {
        Start-Sleep -Milliseconds 200
        if ($progressBar.Value -lt 90) { $progressBar.Value += 5 }
        [System.Windows.Forms.Application]::DoEvents()
    }

    Receive-Job $job | ForEach-Object {
        $logBox.AppendText($_ + "`r`n")
    }
    Remove-Job $job
    $progressBar.Value = 100
    $logBox.AppendText("Finished $scriptName.`r`n`r`n")
}

$scripts = @(
    @{Text = "Debloat & Services"; Script = "debloat_services.ps1"},
    @{Text = "AI & Search Junk"; Script = "ai_bing_copilot.ps1"},
    @{Text = "Performance Tweaks"; Script = "performance_tweaks.ps1"},
    @{Text = "Advanced Cleanup"; Script = "other_tweaks.ps1"}
)

[int]$startX = 20
[int]$startY = 120
[int]$buttonWidth = 180
[int]$buttonHeight = 40
[int]$gap = 20

for ($i = 0; $i -lt $scripts.Count; $i++) {
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = $scripts[$i].Text
    $btn.Size = New-Object System.Drawing.Size($buttonWidth, $buttonHeight)

    $posX = $startX + ($i * ($buttonWidth + $gap))
    $posY = $startY

    $btn.Location = New-Object System.Drawing.Point($posX, $posY)

    $btn.BackColor = "DimGray"
    $btn.ForeColor = "White"
    $btn.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)

    $scriptName = $scripts[$i].Script
    $btn.Add_Click([scriptblock]::Create("Run-Script `"$scriptName`""))

    $form.Controls.Add($btn)
}

[void]$form.ShowDialog()
