# performance_tweaks.ps1
Write-Host "Starting performance tweaks..." -ForegroundColor Cyan

# --------------------------
# Disable Windows Visual Effects for better performance
Write-Host "Disabling unnecessary visual effects..."

$visualFXPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"
New-Item -Path $visualFXPath -Force | Out-Null
Set-ItemProperty -Path $visualFXPath -Name "VisualFXSetting" -Value 2 -Force

# Enable Dark Mode for system and apps
Write-Host "Enabling dark mode for system and apps..."
$personalizePath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
New-Item -Path $personalizePath -Force | Out-Null
Set-ItemProperty -Path $personalizePath -Name "AppsUseLightTheme" -Value 0 -Force
Set-ItemProperty -Path $personalizePath -Name "SystemUsesLightTheme" -Value 0 -Force
Set-ItemProperty -Path $personalizePath -Name "EnableTransparency" -Value 0 -Force

# --------------------------
# Disable Windows Game Bar and Fullscreen Optimizations (FSO) (optional)
Write-Host "Disabling Fullscreen Optimizations and Game Bar..."
$FSOPath = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR"
Set-ItemProperty -Path $FSOPath -Name "AppCaptureEnabled" -Value 0 -Force -ErrorAction SilentlyContinue
Set-ItemProperty -Path $FSOPath -Name "GameDVR_Enabled" -Value 0 -Force -ErrorAction SilentlyContinue

$GameBarPath = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR"
Set-ItemProperty -Path $GameBarPath -Name "BroadcastingEnabled" -Value 0 -Force -ErrorAction SilentlyContinue
Set-ItemProperty -Path $GameBarPath -Name "BroadcastingAllowed" -Value 0 -Force -ErrorAction SilentlyContinue

# Disable FSO for all applications (registry)
$FSOGlobalPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel"
New-ItemProperty -Path $FSOGlobalPath -Name "MitigationOptions" -PropertyType DWord -Value 0x2000000 -Force | Out-Null

# --------------------------
# NVIDIA P-State 0 Registry tweak (force max performance)
Write-Host "Applying NVIDIA max performance registry tweak..."
try {
    $nvidiaKeys = (Get-ChildItem "HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}") | Where-Object {
        (Get-ItemProperty $_.PSPath).DriverDesc -like "*NVIDIA*"
    }
    foreach ($key in $nvidiaKeys) {
        Set-ItemProperty -Path $key.PSPath -Name "DisableDynamicPstate" -Value 1 -Type DWord -Force
    }
} catch {
    Write-Host "NVIDIA registry tweak failed or no NVIDIA card detected." -ForegroundColor Yellow
}

# --------------------------
# AMD Multi-Plane Overlay disable tweak
Write-Host "Disabling AMD Multi-Plane Overlay (if applicable)..."
try {
    Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Dwm" -Name "OverlayTestMode" -Value 5 -Type DWord -Force
} catch {
    Write-Host "AMD MPO tweak failed or not applicable." -ForegroundColor Yellow
}

# --------------------------
# Increase Windows Timer Resolution (using TimerTool)
Write-Host "Increasing Windows timer resolution..."

$timerToolPath = "$PSScriptRoot\timerset.exe"
if (Test-Path $timerToolPath) {
    Start-Process -FilePath $timerToolPath -ArgumentList "-q" -WindowStyle Hidden
} else {
    Write-Host "Timer tool not found. Skipping timer resolution tweak." -ForegroundColor Yellow
}

# --------------------------
# Disable power-saving features in the active power plan (AtlasOS style)
Write-Host "Disabling power-saving features in the active power plan..."

$activeSchemeOutput = powercfg /getactivescheme
if ($activeSchemeOutput -match '{[0-9a-fA-F-]+}') {
    $activeScheme = $matches[0]
    powercfg /setacvalueindex $activeScheme SUB_PROCESSOR PROCTHROTTLEMIN 100
    powercfg /setacvalueindex $activeScheme SUB_PROCESSOR PROCTHROTTLEMAX 100
    powercfg /setdcvalueindex $activeScheme SUB_PROCESSOR PROCTHROTTLEMIN 100
    powercfg /setdcvalueindex $activeScheme SUB_PROCESSOR PROCTHROTTLEMAX 100

    powercfg /setacvalueindex $activeScheme SUB_PROCESSOR IDLEDISABLE 1
    powercfg /setdcvalueindex $activeScheme SUB_PROCESSOR IDLEDISABLE 1

    powercfg /setacvalueindex $activeScheme SUB_PROCESSOR SYSTEMCOOLINGPOLICY 0
    powercfg /setdcvalueindex $activeScheme SUB_PROCESSOR SYSTEMCOOLINGPOLICY 0

    powercfg /setacvalueindex $activeScheme SUB_DISK DISKIDLE 0
    powercfg /setdcvalueindex $activeScheme SUB_DISK DISKIDLE 0

    powercfg /setacvalueindex $activeScheme SUB_USB USBSELECTSUSPEND 0
    powercfg /setdcvalueindex $activeScheme SUB_USB USBSELECTSUSPEND 0

    powercfg /setacvalueindex $activeScheme SUB_PCIEXPRESS ASPM 0
    powercfg /setdcvalueindex $activeScheme SUB_PCIEXPRESS ASPM 0

    powercfg /setacvalueindex $activeScheme SUB_SLEEP STANDBYIDLE 0
    powercfg /setdcvalueindex $activeScheme SUB_SLEEP STANDBYIDLE 0

    powercfg /setacvalueindex $activeScheme SUB_SLEEP HIBERNATEIDLE 0
    powercfg /setdcvalueindex $activeScheme SUB_SLEEP HIBERNATEIDLE 0

    powercfg /setactive $activeScheme

    Write-Host "Power-saving features disabled in the active power plan."
} else {
    Write-Host "Failed to retrieve active power scheme GUID." -ForegroundColor Red
}

Write-Host "`nPerformance tweaks completed!" -ForegroundColor Green
