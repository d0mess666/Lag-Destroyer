# Debloat & Disable Services Script by d0mess666

Write-Host "`n[-] Removing bloatware apps..." -ForegroundColor Yellow

$bloatApps = @(
    "Microsoft.ZuneMusic",
    "Microsoft.ZuneVideo",
    "Microsoft.XboxGameOverlay",
    "Microsoft.XboxGamingOverlay",
    "Microsoft.XboxSpeechToTextOverlay",
    "Microsoft.Xbox.TCUI",
    "Microsoft.XboxApp",
    "Microsoft.XboxIdentityProvider",
    "Microsoft.BingWeather",
    "Microsoft.GetHelp",
    "Microsoft.Getstarted",
    "Microsoft.Microsoft3DViewer",
    "Microsoft.MicrosoftOfficeHub",
    "Microsoft.MicrosoftSolitaireCollection",
    "Microsoft.MicrosoftStickyNotes",
    "Microsoft.MixedReality.Portal",
    "Microsoft.Office.OneNote",
    "Microsoft.People",
    "Microsoft.Print3D",
    "Microsoft.SkypeApp",
    "Microsoft.WindowsAlarms",
    "Microsoft.WindowsCamera",
    "Microsoft.WindowsMaps",
    "Microsoft.WindowsSoundRecorder",
    "Microsoft.YourPhone",
    "Microsoft.WindowsFeedbackHub",
    "Microsoft.MSPaint",
    "Microsoft.Todos",
    "Microsoft.News",
    "Microsoft.Wallet",
    "Microsoft.Whiteboard",
    "Microsoft.549981C3F5F10"  # Cortana
)

foreach ($app in $bloatApps) {
    Get-AppxPackage -Name $app -AllUsers -ErrorAction SilentlyContinue | Remove-AppxPackage -ErrorAction SilentlyContinue
    Get-AppxProvisionedPackage -Online | Where-Object DisplayName -EQ $app | ForEach-Object {
        Remove-AppxProvisionedPackage -Online -PackageName $_.PackageName -ErrorAction SilentlyContinue
    }
    Write-Host "   > Removed: $app" -ForegroundColor DarkGray
}

Write-Host "`n[+] Disabling unnecessary services..." -ForegroundColor Yellow

$servicesToDisable = @(
    "DiagTrack",             # Connected User Experiences and Telemetry
    "dmwappushservice",      # WAP Push Message Routing Service
    "RetailDemo",            # Retail Demo Service
    "XblGameSave",           # Xbox Live Game Save
    "XboxNetApiSvc",         # Xbox Live Networking Service
    "XboxGipSvc"             # Xbox Accessory Management
)

foreach ($svc in $servicesToDisable) {
    Get-Service -Name $svc -ErrorAction SilentlyContinue | ForEach-Object {
        Stop-Service -Name $_.Name -Force -ErrorAction SilentlyContinue
        Set-Service -Name $_.Name -StartupType Disabled -ErrorAction SilentlyContinue
        Write-Host "   > Disabled service: $($_.Name)" -ForegroundColor DarkGray
    }
}

Write-Host "`n[+] Bloatware and services removed/disabled." -ForegroundColor Green
