# Debloat & Disable Services Script by d0mess666 (upraveno pro tvrdé odstranění AI/Bing/Copilot)

Write-Host "`n[-] Removing bloatware apps..." -ForegroundColor Yellow

$bloatApps = @(
    "Microsoft.ZuneMusic",
    "Microsoft.ZuneVideo",
    "Microsoft.XboxGameOverlay",
    "Microsoft.XboxGamingOverlay",
    "Microsoft.XboxSpeechToTextOverlay",
    "Microsoft.Xbox.TCUI",
    "Microsoft.XboxApp",
    "Microsoft.XboxIdentityProvider",
    "Microsoft.BingWeather",
    "Microsoft.GetHelp",
    "Microsoft.Getstarted",                   # Tips
    "Microsoft.Microsoft3DViewer",
    "Microsoft.MicrosoftOfficeHub",
    "Microsoft.MicrosoftSolitaireCollection",
    "Microsoft.MicrosoftStickyNotes",
    "Microsoft.MixedReality.Portal",
    "Microsoft.Office.OneNote",               # OneNote
    "Microsoft.People",                       # People app
    "Microsoft.Print3D",
    "Microsoft.SkypeApp",
    "Microsoft.WindowsAlarms",
    "Microsoft.WindowsCamera",
    "Microsoft.WindowsMaps",
    "Microsoft.WindowsSoundRecorder",
    "Microsoft.YourPhone",
    "Microsoft.WindowsFeedbackHub",          # Feedback Hub
    "Microsoft.MSPaint",
    "Microsoft.Todos",
    "Microsoft.News",
    "Microsoft.Wallet",
    "Microsoft.Whiteboard",
    "Microsoft.549981C3F10",                  # Cortana
    "MicrosoftWindows.Client.WebExperience"  # Microsoft Start (news, widgets)
)

foreach ($app in $bloatApps) {
    Get-AppxPackage -Name $app -AllUsers -ErrorAction SilentlyContinue | Remove-AppxPackage -ErrorAction SilentlyContinue
    Get-AppxProvisionedPackage -Online | Where-Object DisplayName -EQ $app | ForEach-Object {
        Remove-AppxProvisionedPackage -Online -PackageName $_.PackageName -ErrorAction SilentlyContinue
    }
    Write-Host "   > Removed: $app" -ForegroundColor DarkGray
}

Write-Host "`n[+] Removing related policies and registry entries..." -ForegroundColor Yellow

# Cortana policies
$searchPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search"
if (Test-Path $searchPath) { Remove-Item $searchPath -Recurse -Force -ErrorAction SilentlyContinue }

# Copilot policies
$copilotPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot"
if (Test-Path $copilotPath) { Remove-Item $copilotPath -Recurse -Force -ErrorAction SilentlyContinue }

# AI Features policies
$aiFeaturesPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AIFeatures"
if (Test-Path $aiFeaturesPath) { Remove-Item $aiFeaturesPath -Recurse -Force -ErrorAction SilentlyContinue }

# Recall Snapshots
$recallPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Recall"
if (Test-Path $recallPath) { Remove-Item $recallPath -Recurse -Force -ErrorAction SilentlyContinue }

# Disable additional services
Write-Host "`n[+] Disabling additional unnecessary services..." -ForegroundColor Yellow

Stop-Service -Name WSearch -Force -ErrorAction SilentlyContinue
Set-Service -Name WSearch -StartupType Disabled -ErrorAction SilentlyContinue
Write-Host "   > Disabled Windows Search" -ForegroundColor DarkGray

Stop-Service -Name WaaSMedicSvc -Force -ErrorAction SilentlyContinue
Set-Service -Name WaaSMedicSvc -StartupType Disabled -ErrorAction SilentlyContinue
Write-Host "   > Disabled Windows Update Medic Service" -ForegroundColor DarkGray

Stop-Service -Name DPS -Force -ErrorAction SilentlyContinue
Set-Service -Name DPS -StartupType Disabled -ErrorAction SilentlyContinue
Write-Host "   > Disabled Diagnostic Policy Service" -ForegroundColor DarkGray

Stop-Service -Name WerSvc -Force -ErrorAction SilentlyContinue
Set-Service -Name WerSvc -StartupType Disabled -ErrorAction SilentlyContinue
Write-Host "   > Disabled Windows Error Reporting Service" -ForegroundColor DarkGray

# Disable Background Apps (for current user)
$backgroundAppsPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications"
if (Test-Path $backgroundAppsPath) {
    Set-ItemProperty -Path $backgroundAppsPath -Name "*" -Value 0 -ErrorAction SilentlyContinue
    Write-Host "   > Disabled Background Apps for current user" -ForegroundColor DarkGray
}

# Spotlight + Ads + Tips (Current user)
$spotlightPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"
if (Test-Path $spotlightPath) {
    Remove-ItemProperty -Path $spotlightPath -Name "RotatingLockScreenEnabled","RotatingLockScreenOverlayEnabled","SubscribedContent-310093Enabled","SubscribedContent-338388Enabled" -ErrorAction SilentlyContinue
}

# User engagement / Ads disabling (Current user)
$adsPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement"
if (Test-Path $adsPath) {
    Remove-ItemProperty -Path $adsPath -Name "ScoobeSystemSettingEnabled","SilentInstalledAppsEnabled" -ErrorAction SilentlyContinue
}

Write-Host "`n[+] Disabling unnecessary services..." -ForegroundColor Yellow

$servicesToDisable = @(
    "DiagTrack",             # Connected User Experiences and Telemetry
    "dmwappushservice",      # WAP Push Message Routing Service
    "RetailDemo",            # Retail Demo Service
    "XblGameSave",           # Xbox Live Game Save
    "XboxNetApiSvc",         # Xbox Live Networking Service
    "XboxGipSvc",            # Xbox Accessory Management
    "XboxLiveAuthManager",   # Xbox Live Authentication
    "XboxLiveNetworkingSvc"  # Xbox Live Networking Service
)

foreach ($svc in $servicesToDisable) {
    if (Get-Service -Name $svc -ErrorAction SilentlyContinue) {
        Stop-Service -Name $svc -Force -ErrorAction SilentlyContinue
        Set-Service -Name $svc -StartupType Disabled -ErrorAction SilentlyContinue
        Write-Host "   > Disabled service: $svc" -ForegroundColor DarkGray
    }
}

Write-Host "`n[+] Bloatware apps removed, policies cleaned, and services disabled." -ForegroundColor Green
Write-Host "Restart your PC to apply all changes." -ForegroundColor Yellow
