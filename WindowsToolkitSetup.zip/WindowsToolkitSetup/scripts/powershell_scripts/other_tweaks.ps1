# Other Useful Tweaks by d0mess666

Write-Host "`n[+] Applying other system tweaks..." -ForegroundColor Yellow

# Disable Fast Startup
powercfg /hibernate off
Write-Host "   > Disabled Fast Startup (hibernation)" -ForegroundColor DarkGray

# Disable Sticky Keys shortcut (Win11)
Set-ItemProperty -Path "HKCU:\Control Panel\Accessibility\StickyKeys" -Name "Flags" -Value "506" -Force

# Enable showing hidden files, extensions, full path in title bar
$explorer = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
Set-ItemProperty -Path $explorer -Name "Hidden" -Value 1 -Force
Set-ItemProperty -Path $explorer -Name "HideFileExt" -Value 0 -Force
Set-ItemProperty -Path $explorer -Name "ShowSuperHidden" -Value 1 -Force
Set-ItemProperty -Path $explorer -Name "ShowFullPathAddress" -Value 1 -Force

Write-Host "   > File Explorer tweaked" -ForegroundColor DarkGray

# Disable mouse acceleration (Enhance Pointer Precision)
Set-ItemProperty -Path "HKCU:\Control Panel\Mouse" -Name "MouseSpeed" -Value "0"
Set-ItemProperty -Path "HKCU:\Control Panel\Mouse" -Name "MouseThreshold1" -Value "0"
Set-ItemProperty -Path "HKCU:\Control Panel\Mouse" -Name "MouseThreshold2" -Value "0"
Write-Host "   > Mouse acceleration disabled" -ForegroundColor DarkGray

# Restore Win10-style context menu (Windows 11 only)
if ((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").CurrentBuild -ge 22000) {
    New-Item -Path "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32" -Force | Out-Null
    Set-ItemProperty -Path "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32" -Name "(Default)" -Value "" -Force
    Write-Host "   > Win10-style context menu restored" -ForegroundColor DarkGray
}

# Attempt to set Task Manager dark mode (Windows 11 22H2+)
$taskmgrTheme = "HKCU:\Software\Microsoft\Windows\CurrentVersion\TaskManager"
New-Item -Path $taskmgrTheme -Force | Out-Null
Set-ItemProperty -Path $taskmgrTheme -Name "PreferredTheme" -Value "Dark" -Type String -Force
Write-Host "   > Task Manager theme set to dark (if supported)" -ForegroundColor DarkGray

Write-Host "`n Tweaks are Finished." -ForegroundColor Green
