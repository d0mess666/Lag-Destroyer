# performance_tweaks.ps1
Write-Host "Starting performance tweaks..." -ForegroundColor Cyan

# --------------------------
# Disable Windows Visual Effects for better performance
Write-Host "Disabling unnecessary visual effects..."

$visualFXPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"
New-Item -Path $visualFXPath -Force | Out-Null
Set-ItemProperty -Path $visualFXPath -Name "VisualFXSetting" -Value 2 -Force

# Vypnutí animací minimalizace oken
Set-ItemProperty -Path "HKCU:\Control Panel\Desktop\WindowMetrics" -Name "MinAnimate" -Value "0" -Force

# Zrychlení zobrazování menu (ms delay)
Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name "MenuShowDelay" -Value "0" -Force

# Vypnutí animací nabídky Start
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" -Name "TaskbarAnimations" -Value 0 -Force

# Vypnutí stínů v seznamu
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" -Name "ListviewShadow" -Value 0 -Force

# Vypnutí Aero peek (průhlednost oken)
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\DWM" -Name "EnableAeroPeek" -Value 0 -Force


# Enable Dark Mode for system and apps
Write-Host "Enabling dark mode for system and apps..."
$personalizePath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
New-Item -Path $personalizePath -Force | Out-Null
Set-ItemProperty -Path $personalizePath -Name "AppsUseLightTheme" -Value 0 -Force
Set-ItemProperty -Path $personalizePath -Name "SystemUsesLightTheme" -Value 0 -Force
Set-ItemProperty -Path $personalizePath -Name "EnableTransparency" -Value 0 -Force

# --------------------------
# Disable Windows Game Bar and Fullscreen Optimizations (FSO) (optional)
Write-Host "Disabling Fullscreen Optimizations and Game Bar..."
$FSOPath = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR"
Set-ItemProperty -Path $FSOPath -Name "AppCaptureEnabled" -Value 0 -Force -ErrorAction SilentlyContinue
Set-ItemProperty -Path $FSOPath -Name "GameDVR_Enabled" -Value 0 -Force -ErrorAction SilentlyContinue
Set-ItemProperty -Path $FSOPath -Name "BroadcastingEnabled" -Value 0 -Force -ErrorAction SilentlyContinue
Set-ItemProperty -Path $FSOPath -Name "BroadcastingAllowed" -Value 0 -Force -ErrorAction SilentlyContinue

# Disable FSO for all applications (registry)
$FSOGlobalPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel"
New-ItemProperty -Path $FSOGlobalPath -Name "MitigationOptions" -PropertyType DWord -Value 0x2000000 -Force | Out-Null

# --- Vypnutí Delivery Optimization ---
New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" -Force | Out-Null
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" -Name "DoDownloadMode" -Type DWord -Value 0

# --- Vypnutí Telemetrie ---
New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Force | Out-Null
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "AllowTelemetry" -Type DWord -Value 0

# --- Vypnutí Background Apps ---
New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\BackgroundAccessApplications" -Force | Out-Null
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\BackgroundAccessApplications" -Name "GlobalUserDisabled" -Type DWord -Value 1

# --- Vypnutí Feedback Hub ---
New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Feedback" -Force | Out-Null
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Feedback" -Name "FeedbackNotificationMode" -Type DWord -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Feedback" -Name "NumberOfSIUFInPeriod" -Type DWord -Value 0

Write-Host "Hotovo: Telemetrie, pozadí a feedback byly vypnuty. Ping a TCP/IP nastavení zůstalo beze změny." -ForegroundColor Green


# --------------------------
# NVIDIA P-State 0 Registry tweak (force max performance)
Write-Host "Applying NVIDIA max performance registry tweak..."
try {
    $nvidiaKeys = Get-ChildItem "HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}" | Where-Object {
        (Get-ItemProperty $_.PSPath).DriverDesc -like "*NVIDIA*"
    }
    foreach ($key in $nvidiaKeys) {
        Set-ItemProperty -Path $key.PSPath -Name "DisableDynamicPstate" -Value 1 -Type DWord -Force
    }
} catch {
    Write-Host "NVIDIA registry tweak failed or no NVIDIA card detected." -ForegroundColor Yellow
}

# --------------------------
# AMD Multi-Plane Overlay disable tweak
Write-Host "Disabling AMD Multi-Plane Overlay (if applicable)..."
try {
    Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Dwm" -Name "OverlayTestMode" -Value 5 -Type DWord -Force
} catch {
    Write-Host "AMD MPO tweak failed or not applicable." -ForegroundColor Yellow
}

# --------------------------
# Increase Windows Timer Resolution (using TimerTool)
Write-Host "Increasing Windows timer resolution..."

$timerToolPath = "$PSScriptRoot\timerset.exe"
if (Test-Path $timerToolPath) {
    Start-Process -FilePath $timerToolPath -ArgumentList "-q" -WindowStyle Hidden
} else {
    Write-Host "Timer tool not found. Skipping timer resolution tweak." -ForegroundColor Yellow
}

# --------------------------
Write-Host "`n[+] Kontrola a aktivace Ultimate Performance plánu..."

# GUID Ultimate Performance plánu
$ultimateGUID = "e9a42b02-d5df-448d-aa00-03f14749eb61"

# Získat seznam všech dostupných plánů
$plans = powercfg /list

if ($plans -notmatch $ultimateGUID) {
    Write-Host "[*] Ultimate Performance plán není aktivní, pokusím se jej povolit..."
    powercfg -duplicatescheme SCHEME_MIN  # Minimum power plan jako fallback (jen pro jistotu)
    powercfg -setactive SCHEME_MIN
    # Povolit Ultimate Performance (jen pro Windows 10/11 Pro+)
    powercfg -attributes $ultimateGUID -ATTRIB_HIDE
}

Write-Host "[*] Duplikace Ultimate Performance plánu..."

$createOutput = powercfg -duplicatescheme $ultimateGUID
if ($createOutput -match "{[0-9a-fA-F\-]+}") {
    $newGUID = $matches[0]

    # Nastavení jména a popisu podle přání
    $planName = "FckWin Ultimate power."
    $planDesc = "Better power plan for pc then classic windows power plan"

    Write-Host "[*] Přejmenování a nastavení popisu plánu..."
    powercfg -changename $newGUID "$planName" "$planDesc"

    Write-Host "[*] Nastavení plánu jako aktivního..."
    powercfg -setactive $newGUID

    # Záloha předchozího plánu (aktuálně aktivního před tímto)
    $currentPlan = (powercfg /getactivescheme) -replace ".*:\s*", ""
    Write-Host "[i] Předchozí aktivní plán byl: $currentPlan"

    Write-Host "[*] Optimalizace nastavení plánu..."

    powercfg /setacvalueindex $newGUID SUB_PROCESSOR PROCTHROTTLEMIN 100
    powercfg /setacvalueindex $newGUID SUB_PROCESSOR PROCTHROTTLEMAX 100
    powercfg /setdcvalueindex $newGUID SUB_PROCESSOR PROCTHROTTLEMIN 100
    powercfg /setdcvalueindex $newGUID SUB_PROCESSOR PROCTHROTTLEMAX 100

    powercfg /setacvalueindex $newGUID SUB_PROCESSOR IDLEDISABLE 1
    powercfg /setdcvalueindex $newGUID SUB_PROCESSOR IDLEDISABLE 1

    powercfg /setacvalueindex $newGUID SUB_PROCESSOR SYSTEMCOOLINGPOLICY 0
    powercfg /setdcvalueindex $newGUID SUB_PROCESSOR SYSTEMCOOLINGPOLICY 0

    powercfg /setacvalueindex $newGUID SUB_DISK DISKIDLE 0
    powercfg /setdcvalueindex $newGUID SUB_DISK DISKIDLE 0

    powercfg /setacvalueindex $newGUID SUB_USB USBSELECTSUSPEND 0
    powercfg /setdcvalueindex $newGUID SUB_USB USBSELECTSUSPEND 0

    powercfg /setacvalueindex $newGUID SUB_PCIEXPRESS ASPM 0
    powercfg /setdcvalueindex $newGUID SUB_PCIEXPRESS ASPM 0

    powercfg /setacvalueindex $newGUID SUB_SLEEP STANDBYIDLE 0
    powercfg /setdcvalueindex $newGUID SUB_SLEEP STANDBYIDLE 0

    powercfg /setacvalueindex $newGUID SUB_SLEEP HIBERNATEIDLE 0
    powercfg /setdcvalueindex $newGUID SUB_SLEEP HIBERNATEIDLE 0

    Write-Host "[OK] Hotovo! Nový power plán '$planName' je aktivní." -ForegroundColor Green
} else {
    Write-Host "[ERROR] Nepodařilo se vytvořit nový power plán." -ForegroundColor Red
}


Write-Host "`n[✓] LagDestroyer Plan created, optimized and activated!" -ForegroundColor Green

Write-Host "`nPerformance tweaks completed!" -ForegroundColor Green
