Write-Host 'Disabling Bing, Copilot, Cortana and AI features...' -ForegroundColor Yellow

# -------------------------
# [-] REMOVE AI & BING APPS
# -------------------------

# Remove Cortana (App + Provisioned)
Get-AppxPackage -Name "Microsoft.549981C3F5F10" -AllUsers | Remove-AppxPackage -ErrorAction SilentlyContinue
Remove-AppxProvisionedPackage -Online -PackageName "Microsoft.549981C3F5F10" -ErrorAction SilentlyContinue

# Remove Microsoft Start (News/Bing/Widgets hybrid app)
Get-AppxPackage -Name "MicrosoftWindows.Client.WebExperience" -AllUsers | Remove-AppxPackage -ErrorAction SilentlyContinue
Remove-AppxProvisionedPackage -Online -PackageName "MicrosoftWindows.Client.WebExperience" -ErrorAction SilentlyContinue

# Remove Tips app (promotes Copilot/Bing)
Get-AppxPackage -Name "Microsoft.Getstarted" -AllUsers | Remove-AppxPackage -ErrorAction SilentlyContinue
Remove-AppxProvisionedPackage -Online -PackageName "Microsoft.Getstarted" -ErrorAction SilentlyContinue

# Odinstalace Copilot aplikace pro všechny uživatele
Get-AppxPackage -AllUsers *Microsoft.Copilot* | Remove-AppxPackage -AllUsers

# Smazání zbytků po Copilotu
Remove-Item -Path "C:\Program Files\WindowsApps\Microsoft.Copilot*" -Recurse -Force -ErrorAction SilentlyContinue

# Remove Feedback Hub (telemetry-related)
Get-AppxPackage -Name "Microsoft.WindowsFeedbackHub" -AllUsers | Remove-AppxPackage -ErrorAction SilentlyContinue
Remove-AppxProvisionedPackage -Online -PackageName "Microsoft.WindowsFeedbackHub" -ErrorAction SilentlyContinue

# Remove People app
Get-AppxPackage -Name "Microsoft.People" -AllUsers | Remove-AppxPackage -ErrorAction SilentlyContinue
Remove-AppxProvisionedPackage -Online -PackageName "Microsoft.People" -ErrorAction SilentlyContinue

# Remove OneNote (sometimes AI-integrated)
Get-AppxPackage -Name "Microsoft.Office.OneNote" -AllUsers | Remove-AppxPackage -ErrorAction SilentlyContinue
Remove-AppxProvisionedPackage -Online -PackageName "Microsoft.Office.OneNote" -ErrorAction SilentlyContinue

# Optional: Restart Explorer to apply Copilot icon removal
Stop-Process -Name explorer -Force
Start-Sleep -Seconds 1
Start-Process explorer.exe

# -------------------------
# [X] DISABLE AI FEATURES
# -------------------------

# Cortana policy
$searchPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search"
New-Item -Path $searchPath -Force | Out-Null
Set-ItemProperty -Path $searchPath -Name "AllowCortana" -Value 0 -Type DWord -Force
Set-ItemProperty -Path $searchPath -Name "DisableWebSearch" -Value 1 -Type DWord -Force
Set-ItemProperty -Path $searchPath -Name "ConnectedSearchUseWeb" -Value 0 -Type DWord -Force

# Microsoft Copilot
$copilotPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot"
New-Item -Path $copilotPath -Force | Out-Null
Set-ItemProperty -Path $copilotPath -Name "TurnOffWindowsCopilot" -Value 1 -Type DWord -Force
Set-ItemProperty -Path $copilotPath -Name "DisableCopilot" -Value 1 -Type DWord -Force
Set-ItemProperty -Path $copilotPath -Name "AllowCopilot" -Value 0 -Type DWord -Force

# AI in Paint and Notepad
$aiFeaturesPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AIFeatures"
New-Item -Path $aiFeaturesPath -Force | Out-Null
Set-ItemProperty -Path $aiFeaturesPath -Name "DisablePaintAI" -Value 1 -Type DWord -Force
Set-ItemProperty -Path $aiFeaturesPath -Name "DisableNotepadAI" -Value 1 -Type DWord -Force

# Recall Snapshots
$recallPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Recall"
New-Item -Path $recallPath -Force | Out-Null
Set-ItemProperty -Path $recallPath -Name "DisableRecallSnapshots" -Value 1 -Type DWord -Force

# Spotlight + Ads + Tips
$spotlightPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"
Set-ItemProperty -Path $spotlightPath -Name "RotatingLockScreenEnabled" -Value 0 -Force -ErrorAction SilentlyContinue
Set-ItemProperty -Path $spotlightPath -Name "RotatingLockScreenOverlayEnabled" -Value 0 -Force -ErrorAction SilentlyContinue
Set-ItemProperty -Path $spotlightPath -Name "SubscribedContent-310093Enabled" -Value 0 -Force -ErrorAction SilentlyContinue
Set-ItemProperty -Path $spotlightPath -Name "SubscribedContent-338388Enabled" -Value 0 -Force -ErrorAction SilentlyContinue

# User engagement / Ads disabling
$adsPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement"
Set-ItemProperty -Path $adsPath -Name "ScoobeSystemSettingEnabled" -Value 0 -Force -ErrorAction SilentlyContinue
Set-ItemProperty -Path $adsPath -Name "SilentInstalledAppsEnabled" -Value 0 -Force -ErrorAction SilentlyContinue

Write-Host "`n[+] Bing, Copilot, Cortana, AI apps and features fully disabled and removed." -ForegroundColor Green
