import os
import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QTextEdit, QProgressBar, QMessageBox
from PyQt6.QtGui import QFont
from PyQt6.QtCore import Qt, QProcess

class TweakTool(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Windows Toolkit Setup")
        self.setGeometry(100, 100, 800, 500)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        
        title = QLabel("Windows Toolkit Setup")
        title.setFont(QFont("Arial", 20))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        subtitle = QLabel("Minimal performance & debloat utility for Windows 11")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)

        button_layout = QHBoxLayout()
        scripts_subfolder = "powershell_scripts"
        scripts_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "scripts", scripts_subfolder)

        buttons = [
            ("Debloat & Services", "debloat_services.ps1"),
            ("AI & Search Junk", "ai_bing_copilot.ps1"),
            ("Performance Tweaks", "performance_tweaks.ps1"),
            ("Other Tweaks", "other_tweaks.ps1")
        ]

        for name, script in buttons:
            btn = QPushButton(name)
            btn.clicked.connect(lambda _, s=script: self.run_script(os.path.join(scripts_path, s)))
            button_layout.addWidget(btn)
        layout.addLayout(button_layout)

        self.progress = QProgressBar()
        layout.addWidget(self.progress)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log)

        github_link = QLabel('<a href="https://github.com/d0mess666/windows-toolkit">GitHub Repo</a>')
        github_link.setOpenExternalLinks(True)
        github_link.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(github_link)

        license_label = QLabel("© 2025 d0mess666 - MIT License")
        license_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(license_label)

        self.setLayout(layout)

    def run_script(self, script_path):
        if not os.path.exists(script_path):
            QMessageBox.critical(self, "Error", f"Script not found:\n{script_path}")
            return

        self.progress.setValue(0)
        self.log.append(f"Running: {os.path.basename(script_path)}...")

        self.process = QProcess(self)
        self.process.readyReadStandardOutput.connect(self.on_stdout)
        self.process.readyReadStandardError.connect(self.on_stderr)
        self.process.finished.connect(lambda: self.progress.setValue(100))
        self.process.start("powershell", ["-ExecutionPolicy", "Bypass", "-File", script_path])

    def on_stdout(self):
        output = self.process.readAllStandardOutput().data().decode('utf-8').strip()
        if output:
            self.log.append(output)

    def on_stderr(self):
        error = self.process.readAllStandardError().data().decode('utf-8').strip()
        if error:
            self.log.append(f"<span style='color:red;'>{error}</span>")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = TweakTool()
    window.show()
    sys.exit(app.exec())
