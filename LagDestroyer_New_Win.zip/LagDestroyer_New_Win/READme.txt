# 🧨 Lag Destroyer - System Cleaner v2.1

PowerShell utility to remove useless Windows 11 features, restore performance, and clean bloat.

## 🛠 Features

- 🔧 **Remove AI crap & Microsoft Edge**  
  Deletes Copilot, DevHome, Paint, ToDo, and forcibly uninstalls Edge.

- 🎮 **Apply old Windows 10 UI tweaks**  
  Disables rounded corners and visual effects for snappier feel.

- 🧹 **Remove preinstalled bloatware**  
  Cleans Xbox apps, Skype, Mixed Reality, News, 3D Viewer, People, and more.

- 📄 **Log file generated**  
  Every action is logged into `LagDestroyer_Cleanup_Log.txt`.

---

## ⚠️ Use at your own risk

Some removals are irreversible without full system reset.  
Create a **restore point** before using [3] and [1].

---

## ✅ How to use

1. Download both files:
   - `LagDestroyer_AICleaner_v2.1.ps1`
   - `Run_LagDestroyer_AICleaner.bat`
2. Run the `.bat` file **as Administrator**
3. Follow the menu and select actions
4. View the generated log if needed

---

Made with 💀 by [d0mess666](https://github.com/d0mess666/Lag-Destroyer)
