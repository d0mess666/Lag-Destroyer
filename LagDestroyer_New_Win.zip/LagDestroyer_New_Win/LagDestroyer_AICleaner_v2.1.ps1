# Lag Destroyer - System Cleaner v2.1
# Removes AI crap, Edge, Bloatware and restores Windows 10 UI
# Autor: d0mess666

if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltinRole] "Administrator")) {
    Write-Warning "Please run this script as Administrator!"
    Pause
    exit
}

$logPath = "$PSScriptRoot\LagDestroyer_Cleanup_Log.txt"

function Log {
    param([string]$msg)
    "$((Get-Date).ToString("yyyy-MM-dd HH:mm:ss")) - $msg" | Out-File -FilePath $logPath -Append -Encoding utf8
}

function Pause {
    Write-Host "Press any key to continue..."
    [void][System.Console]::ReadKey($true)
}

function Remove-AI-Stuff {
    Write-Host "`n>>> Removing AI crap and Microsoft Edge..." -ForegroundColor Yellow

    $packages = @(
        "MicrosoftWindows.Client.WebExperience", # Copilot
        "Microsoft.Todos",
        "Microsoft.Paint",
        "Microsoft.DevHome",
        "Microsoft.ScreenSketch"
    )

    foreach ($pkg in $packages) {
        Get-AppxPackage -Name $pkg -AllUsers | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue
        Log "Removed AppxPackage: $pkg"
    }

    $edgePath = Get-ChildItem "C:\Program Files (x86)\Microsoft\Edge\Application" -Directory | Sort-Object Name -Descending | Select-Object -First 1
    $installer = Join-Path $edgePath.FullName "Installer\setup.exe"
    if (Test-Path $installer) {
        Start-Process -FilePath $installer -ArgumentList "--uninstall --system-level --force-uninstall --verbose-logging" -Wait
        Log "Edge force-uninstalled via setup.exe"
    }

    Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\TaskbarCopilot" -Force -ErrorAction SilentlyContinue
    Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\ShowCopilotButton" -Force -ErrorAction SilentlyContinue

    Log "Removed registry leftovers from Copilot & AI modules"

    Write-Host "`n✅ AI crap and Edge removed." -ForegroundColor Green
    Pause
}

function Restore-Old-Win10-UI {
    Write-Host "`n>>> Applying Windows 10 style tweaks..." -ForegroundColor Yellow

    Set-ItemProperty -Path "HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32" -Name "(Default)" -Value "" -Force -ErrorAction SilentlyContinue
    $regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"
    Set-ItemProperty -Path $regPath -Name VisualFXSetting -Value 2 -Force
    Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name "UserPreferencesMask" -Value ([byte[]](0x90,0x12,0x03,0x80,0x10,0x00,0x00,0x00)) -Force
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Feeds" -Name "ShellFeedsTaskbarViewMode" -Value 2 -Force

    Log "Applied Windows 10 style tweaks"
    Write-Host "`n✅ UI restored to classic look." -ForegroundColor Green
    Pause
}

function Remove-Bloatware {
    Write-Host "`n>>> Removing preinstalled bloatware..." -ForegroundColor Yellow

    $bloatPackages = @(
        "Microsoft.BingNews",
        "Microsoft.GetHelp",
        "Microsoft.Getstarted",
        "Microsoft.Microsoft3DViewer",
        "Microsoft.MicrosoftOfficeHub",
        "Microsoft.MicrosoftSolitaireCollection",
        "Microsoft.MixedReality.Portal",
        "Microsoft.People",
        "Microsoft.SkypeApp",
        "Microsoft.Wallet",
        "Microsoft.XboxApp",
        "Microsoft.XboxGameOverlay",
        "Microsoft.XboxGamingOverlay",
        "Microsoft.XboxIdentityProvider",
        "Microsoft.XboxSpeechToTextOverlay",
        "Microsoft.YourPhone",
        "Microsoft.ZuneMusic",
        "Microsoft.ZuneVideo"
    )

    foreach ($bloat in $bloatPackages) {
        Get-AppxPackage -Name $bloat -AllUsers | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue
        Log "Removed bloatware: $bloat"
    }

    Write-Host "`n✅ Bloatware removed." -ForegroundColor Green
    Log "All selected bloatware removed."
    Pause
}

function Show-Log {
    if (Test-Path $logPath) {
        notepad $logPath
    } else {
        Write-Host "No log file found." -ForegroundColor Red
        Pause
    }
}

function Show-Menu {
    Clear-Host
    Write-Host ""
    Write-Host "===========================================" -ForegroundColor Cyan
    Write-Host "= Lag Destroyer - System Cleaner v2.1     =" -ForegroundColor Cyan
    Write-Host "= Removes AI bloat, Edge & Win11 garbage =" -ForegroundColor Cyan
    Write-Host "===========================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "   [1] Remove AI crap & Microsoft Edge [Recommended]" -ForegroundColor White
    Write-Host "   [2] Apply Windows 10 style UI         [Optional]" -ForegroundColor White
    Write-Host "   [3] Remove Bloatware (preinstalled)   [Recommended]" -ForegroundColor White
    Write-Host "   [4] Show cleanup log"
    Write-Host "   [5] Exit"
    Write-Host ""
}

do {
    Show-Menu
    $choice = Read-Host "   Choose"

    switch ($choice) {
        "1" { Remove-AI-Stuff }
        "2" { Restore-Old-Win10-UI }
        "3" { Remove-Bloatware }
        "4" { Show-Log }
        "5" { Write-Host "`nExiting..." -ForegroundColor Cyan }
        default {
            Write-Host "`n[!] Invalid input, please choose 1 - 5." -ForegroundColor Red
            Pause
        }
    }
} until ($choice -eq "5")
